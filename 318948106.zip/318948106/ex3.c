//Eden Ahady 318948106
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>
#include <unistd.h>

#define MAX_BUFFER_SIZE 100
#define MAX_ITEM_SIZE 100
#define MAX_CAPACITY 50
struct ItemProducer* ItemProducerArray = NULL;
struct BoundedBuffer screenManager_queue;
struct UnboundedBuffer news_buffer;
struct UnboundedBuffer sports_buffer;
struct UnboundedBuffer weather_buffer;
int ProducerCount = 0;

struct BoundedBuffer {
    // maximum capacity of the buffer
    int capacity;
    // number of items in the buffer
    int count;
    // total number of items inserted into the buffer
    int totalItems;
    // index of the first item
    int head;
    // index of the last item
    int tail;
    // buffer that stores items
    char** items;
    pthread_mutex_t lock;
    pthread_cond_t emptySlots;
    pthread_cond_t filledSlots;
};

void BoundedBuffer_init(struct BoundedBuffer *buffer, int capacity) {
    buffer->capacity = capacity;
    buffer->head = 0;
    buffer->tail = 0;
    buffer->count = 0;
    buffer->totalItems = 0;
    buffer->items = malloc(capacity * sizeof(char*));

    // Initialize the mutex
    pthread_mutex_init(&(buffer->lock), NULL);
    // Initialize the condition variable for empty buffer
    pthread_cond_init(&(buffer->emptySlots), NULL);
    // Initialize the condition variable for full buffer
    pthread_cond_init(&(buffer->filledSlots), NULL);
}


void insert(struct BoundedBuffer *bBuffer, char* s) {
    // mutex lock
    pthread_mutex_lock(&(bBuffer->lock));

    // Wait when the buffer is full
    while (bBuffer->count == bBuffer->capacity) {
        pthread_cond_wait(&(bBuffer->emptySlots), &(bBuffer->lock));
    }

    // Insert the object at the end of the buffer
    bBuffer->items[bBuffer->tail] = strdup(s);
    bBuffer->tail = (bBuffer->tail + 1) % bBuffer->capacity;
    bBuffer->count++;
    // check if the file is not empty
    pthread_cond_signal(&(bBuffer->filledSlots));
    //release the lock
    pthread_mutex_unlock(&(bBuffer->lock));
}


char* BoundedBuffer_remove(struct BoundedBuffer *buffer) {

    // get the lock
    pthread_mutex_lock(&(buffer->lock));

    // Wait until there is a filled slot in the buffer
    while (buffer->count == 0) {
        pthread_cond_wait(&(buffer->filledSlots), &(buffer->lock));
    }

    // Remove the item from the buffer
    char* item = buffer->items[buffer->head];
    buffer->head = (buffer->head + 1) % buffer->capacity;
    buffer->count--;

    // Signal that an empty slot is available
    pthread_cond_signal(&(buffer->emptySlots));

    pthread_mutex_unlock(&(buffer->lock)); // Release the lock

    return item;
}

void BoundedBuffer_destroy(struct BoundedBuffer *buffer) {
    // destroy the mutex
    pthread_mutex_destroy(&(buffer->lock));
    // destroy the empty buffer
    pthread_cond_destroy(&(buffer->emptySlots));
    // destroy the full buffer
    pthread_cond_destroy(&(buffer->filledSlots));

    // Free dynamically allocated memory for buffer items
    for (int i = 0; i < buffer->capacity; i++) {
        free(buffer->items[i]);
    }
    free(buffer->items);
}
struct BufferNode {
    char* msg;
    struct BufferNode* next;
};

struct UnboundedBuffer {
    struct BufferNode* head;
    struct BufferNode* tail;
    pthread_mutex_t mtx;
    sem_t *isEmpty;
    int itemCount;
};

void UnboundedBuffer_init(struct UnboundedBuffer* buffer) {
    //initiate the variables
    buffer->head = NULL;
    buffer->tail = NULL;
    buffer->itemCount = 0;
    pthread_mutex_init(&buffer->mtx, NULL);
    buffer->isEmpty = malloc(sizeof(sem_t));
    sem_init(buffer->isEmpty, 0, 0);
}

void UnboundedBuffer_destroy(struct UnboundedBuffer* buffer) {
    //get the lock
    pthread_mutex_lock(&(buffer->mtx));

    // free all buffer nodes
    struct BufferNode* current = buffer->head;
    while (current != NULL) {
        struct BufferNode* next = current->next;
        free(current->msg);
        free(current);
        current = next;
    }
    // release the lock
    pthread_mutex_unlock(&(buffer->mtx));

    // destroy the mutex and semaphore
    pthread_mutex_destroy(&(buffer->mtx));
    sem_destroy(buffer->isEmpty);
}

void UnboundedBuffer_insert(struct UnboundedBuffer* buffer, char* message) {
    // allocate memory for a new node
    struct BufferNode* newNode = (struct BufferNode*)malloc(sizeof(struct BufferNode));
    newNode->next = NULL;
    // duplicate the message string and assign it to the new node
    newNode->msg = strdup(message);
    // Acquire the lock to ensure exclusive access to the buffer
    pthread_mutex_lock(&buffer->mtx);
    // Check if the buffer is not empty and append the node to the end
    if (buffer->tail != NULL) {
        buffer->tail->next = newNode;
        buffer->tail = newNode;
    } else {
        buffer->head = newNode;
        buffer->tail = newNode;
    }
    buffer->itemCount++;
    // Signal that the buffer is no longer empty
    sem_post(buffer->isEmpty);
    // Release the lock
    pthread_mutex_unlock(&buffer->mtx);
}

char* UnboundedBuffer_remove(struct UnboundedBuffer* buffer) {
    // Wait until the buffer is not empty
    sem_wait(buffer->isEmpty);
    // Acquire the lock
    pthread_mutex_lock(&buffer->mtx);
    struct BufferNode* removed_node = buffer->head;
    // Extract the message from the removed node
    char* message = removed_node->msg;
    buffer->head = buffer->head->next;
    // If the head becomes NULL, it means the buffer is now empty
    if (buffer->head == NULL) {
        buffer->tail = NULL;
    }
    free(removed_node);
    buffer->itemCount--;
    // Release the lock
    pthread_mutex_unlock(&buffer->mtx);
    return message;
}


struct ItemProducer {
    struct BoundedBuffer* itemQueue;
    int producerID;
    int totalItems;
    int itemCount;
    int sportsCount;
    int newsCount;
    int weatherCount;
    int queueSize;
};

void ItemProducer_init(struct ItemProducer *producer, int producerID, int queueSize, int totalItems) {
    //initiate all the variables
    producer->itemQueue = malloc(sizeof(struct BoundedBuffer));
    BoundedBuffer_init(producer->itemQueue, queueSize);
    producer->totalItems = totalItems;
    producer->sportsCount = 0;
    producer->producerID = producerID;
    producer->queueSize = queueSize;
    producer->newsCount = 0;
    producer->weatherCount = 0;
    producer->itemCount = 0;

}



void ItemProducer_destroy(struct ItemProducer *producer) {
    BoundedBuffer_destroy(producer->itemQueue);
    free(producer->itemQueue);
}


void* do_producer(void* arg) {
    struct ItemProducer* prod = (struct Producer*)arg;
    for (int i = 0; i < prod->totalItems; i++) {
        char* idStr = malloc(sizeof(char) * 10);
        char* countStr = malloc(sizeof(char) * 10);
        sprintf(idStr, "%d", prod->producerID);
        // Allocating message as an array with enough size
        char message[MAX_ITEM_SIZE];
        sprintf(message, "Producer %s ", idStr);
        free(idStr);
        char productString[100];
        int randomValue = rand() % 3;
        //checking the choice
        switch (randomValue) {
            case 0:
                sprintf(productString, "SPORTS %d", prod->sportsCount);
                prod->sportsCount++;
                break;
            case 1:
                sprintf(productString, "NEWS %d", prod->newsCount);
                prod->newsCount++;
                break;
            case 2:
                sprintf(productString, "WEATHER %d", prod->weatherCount);
                prod->weatherCount++;
                break;
            default:
                // Handle the default case if needed
                break;
        }
        free(countStr);
        strcat(message, productString);
        strcat(message, "\n");
        insert(prod->itemQueue, message);

        memset(message, 0, sizeof(message));
    }
    insert(prod->itemQueue, "DONE");
    pthread_exit(NULL);
}

void* do_dispatcher(void* arg) {
    char* done_message = "DONE";
    int count_news = 0;

    int all_producers = 0;
    //  current producer index
    int current_producer = 0;

    while (all_producers <  ProducerCount) {
        struct ItemProducer *producer = &ItemProducerArray[current_producer];

        if (producer->queueSize > 0) {
            char *message = BoundedBuffer_remove(producer->itemQueue);
            if (strcmp(message, done_message) == 0) {
                all_producers++;
                free(message);
            } else {

                // check which co-editor queue to insert the message
                char type[10];
                sscanf(message, "%*s %*s %s", type);
                if (strcmp(type, "WEATHER") == 0) {
                    UnboundedBuffer_insert(&weather_buffer, message);
                } else if (strcmp(type, "NEWS") == 0) {
                    UnboundedBuffer_insert(&news_buffer, message);
                } else if (strcmp(type, "SPORTS") == 0) {
                    UnboundedBuffer_insert(&sports_buffer, message);
                }
            }
        }
        // Move to the next producer in a round-robin fashion
        current_producer = (current_producer + 1) % ProducerCount;
    }

    // Forward DONE message to co-editors
    UnboundedBuffer_insert(&news_buffer, done_message);
    UnboundedBuffer_insert(&sports_buffer, done_message);
    UnboundedBuffer_insert(&weather_buffer, done_message);
    pthread_exit(NULL);
}


void* do_coeditors(void* arg) {
    // Cast the argument to the appropriate type
    struct UnboundedBuffer *coeditorBuffer = (struct UnboundedBuffer *) arg;
    // Continue processing until explicitly stopped
    while (1) {
        char *string = UnboundedBuffer_remove(coeditorBuffer);
        if (string != NULL) {
            if (strcmp(string, "DONE") == 0) {
                // Insert "DONE" into the screen manager queue to indicate completion
                insert(&screenManager_queue, "DONE");
                break;
            } else {
                // editing process
                sleep(1);
                // Pass the edited message to the screen manager
                insert(&screenManager_queue, string);
            }
        }
    }
    pthread_exit(NULL);
}

void* screen_manager_thread(void* arg) {
    int doneCount = 0;
    // Continue processing until explicitly stopped
    while (1) {
        char *message = BoundedBuffer_remove(&screenManager_queue);
        // Check if the retrieved message is NULL
        if (message == NULL) {
            continue;
            //free(message);
        } else {
            if (strcmp(message, "DONE") == 0) {
                doneCount++;
                // Check if all three "DONE" messages have been received
                if (doneCount == 3) {
                    printf("DONE\n");
                    //free(message);
                    break;
                }
            } else {
                printf("%s", message);
            }
        }
    }
    // Exit the thread
    pthread_exit(NULL);
}



int main(int argc, char* argv[]) {
    // Check if the correct number of command-line arguments is provided
    if (argc != 2) {
        perror("Invalid argument number.");
        exit(-1);
    }
    // Retrieve the configuration file path from command-line arguments
    char *configPath = argv[1];
    int pro_count = 0;
    int num_coEditor = 0;
    int pro_id, num_products, size;
    // Open the configuration file for reading
    FILE *configFilePtr = fopen(configPath, "r");
    if (configFilePtr == NULL) {
        printf("Error opening config file '%s'\n", configPath);
        exit(1);
    }
    char configLine[MAX_ITEM_SIZE];
    // Read the configuration file line by line
    while (fgets(configLine, sizeof(configLine), configFilePtr) != NULL) {
        if (fgets(configLine, sizeof(configLine), configFilePtr) == NULL) {
            num_coEditor = atoi(configLine);
        } else {
            pro_count++;
            fgets(configLine, sizeof(configLine), configFilePtr);
            fgets(configLine, sizeof(configLine), configFilePtr);
        }
    }
    // Initialize the screen manager queue
    BoundedBuffer_init(&screenManager_queue, num_coEditor);
    ProducerCount = pro_count;
    // Allocate memory for the array of item producers
    ItemProducerArray = malloc(ProducerCount * sizeof(struct ItemProducer));
    fseek(configFilePtr, 0, SEEK_SET);
    int count = 0;
    // Read the configuration file again to initialize item producers
    while (count < ProducerCount) {
        fscanf(configFilePtr, "%d", &pro_id);
        pro_id = pro_id - 1;
        fscanf(configFilePtr, "%d", &num_products);
        fscanf(configFilePtr, "%d", &size);
        // Initialize the item producer with the read values
        ItemProducer_init(&ItemProducerArray[count], pro_id, size, num_products);
        fgets(configLine, sizeof(configLine), configFilePtr);
        count++;
    }
    // Close the configuration file
    fclose(configFilePtr);

    UnboundedBuffer_init(&news_buffer);
    UnboundedBuffer_init(&sports_buffer);
    UnboundedBuffer_init(&weather_buffer);

    pthread_t *producerThreads = malloc(sizeof(pthread_t) * ProducerCount);
    // Create producer threads
    for (int i = 0; i < ProducerCount; i++) {
        pthread_t producerThread;
        if (pthread_create(&producerThread, NULL, do_producer, &ItemProducerArray[i]) != 0) {
            printf("Error in creating thread\n");
        }
        producerThreads[i] = producerThread;
    }
    // Create the dispatcher thread
    pthread_t dispatcherThread;
    if (pthread_create(&dispatcherThread, NULL, do_dispatcher, 0) != 0) {
        printf("Error in creating thread\n");
    }

    // Coeditors threads
    pthread_t coEditorThreads[3];
    if (pthread_create(&coEditorThreads[0], NULL, do_coeditors, &news_buffer) != 0) {
        perror("Error in creating thread");
        exit(-1);
    }
    if (pthread_create(&coEditorThreads[1], NULL, do_coeditors, &sports_buffer) != 0) {
        perror("Error in creating thread");
        exit(-1);
    }
    if (pthread_create(&coEditorThreads[2], NULL, do_coeditors, &weather_buffer) != 0) {
        perror("Error in creating thread");
        exit(-1);
    }
    // Screen manager threads
    pthread_t screenManagerThread;
    if (pthread_create(&screenManagerThread, NULL, screen_manager_thread, 0) != 0) {
        printf("Error in creating thread\n");
    }

    for (int i = 0; i < ProducerCount; i++) {
        if (pthread_join(producerThreads[i], NULL) != 0) {
            printf("Error in joining threads\n");
            exit(-1);
        }
    }
    free(producerThreads);

    if (pthread_join(dispatcherThread, NULL) != 0) {
        printf("Error in joining threads\n");
        exit(-1);
    }

    for (int i = 0; i < 3; i++) {
        if (pthread_join(coEditorThreads[i], NULL) != 0) {
            printf("Error in joining threads\n");
            exit(-1);
        }
    }

    if (pthread_join(screenManagerThread, NULL) != 0) {
        printf("Error in joining threads\n");
        exit(-1);
    }


        UnboundedBuffer_destroy(&news_buffer);
        UnboundedBuffer_destroy(&sports_buffer);
        UnboundedBuffer_destroy(&weather_buffer);
        BoundedBuffer_destroy(&screenManager_queue);

    return 0;
}